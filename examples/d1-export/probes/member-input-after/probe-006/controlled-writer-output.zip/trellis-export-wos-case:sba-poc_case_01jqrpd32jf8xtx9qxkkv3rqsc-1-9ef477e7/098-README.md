# Controlled native writer qualification; synthetic 006-signature-affirmations-inline

- scope (manifest.scope): `wos-case:sba-poc_case_01jqrpd32jf8xtx9qxkkv3rqsc`
- tree_size (manifest.tree_size): `1`
- tree_head_hash (checkpoint[0].tree_head_hash): `9ef477e7d9be148e5d1992efe41ed62f73dff5373c548b480b5fc2425c03b1f5`
- head_checkpoint_digest: `2adf880e2dec6dd888ea94d64183b94c74b2869e137e96b462e52d690ad2f80a`
- registry_digest: `f4dd682b76d36ae0f342b0c3774fc83063bd7c2ff4739018284b5bbd38d7599c`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "Fixture export: envelope reveals event_type, authored_at (1s granularity), retention_tier, classification, ledger_scope, and COSE kid.",
  "provider_readable": true,
  "reader_held": false,
  "recovery_without_user": true
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
