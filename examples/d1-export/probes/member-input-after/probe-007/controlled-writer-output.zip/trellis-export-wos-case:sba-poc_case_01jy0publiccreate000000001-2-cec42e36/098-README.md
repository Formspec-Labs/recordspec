# Controlled native writer qualification; synthetic 007-intake-handoffs-public-create

- scope (manifest.scope): `wos-case:sba-poc_case_01jy0publiccreate000000001`
- tree_size (manifest.tree_size): `2`
- tree_head_hash (checkpoint[1].tree_head_hash): `cec42e3631719ac261dbca93eb8af5bccdf4d1da8a232d741880c9678e71077c`
- head_checkpoint_digest: `c394f8561b33cb912e4f960b35c446d8c2297b3d258326bbc359ad07b093364c`
- registry_digest: `8a207e195abe8e88e05d360eb76557bb33f715fbed1ed1334a3544c79413462d`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "Fixture export: envelope reveals event_type, authored_at (1s granularity), retention_tier, classification, ledger_scope, and COSE kid.",
  "provider_readable": true,
  "reader_held": false,
  "recovery_without_user": true
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
