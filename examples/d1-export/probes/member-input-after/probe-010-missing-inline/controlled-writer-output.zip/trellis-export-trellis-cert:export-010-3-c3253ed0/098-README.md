# Controlled native writer qualification; synthetic 010-certificate-of-completion-inline

- scope (manifest.scope): `trellis-cert:export-010`
- tree_size (manifest.tree_size): `3`
- tree_head_hash (checkpoint[2].tree_head_hash): `c3253ed0bc69cc6b22f7448658a4c7bfdd40b4b5e6efa0c3f402344948598877`
- head_checkpoint_digest: `31dfa19bb9a1de7a25500a605bb2749037678f89bc8cc8a343a198dee3f0fefd`
- registry_digest: `a0c9f644dffed45242002257c27e050c8f012cede3509a1b4b2d5f2f27408878`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "Fixture export: envelope reveals event_type, authored_at (1s granularity), retention_tier, classification, ledger_scope, and COSE kid.",
  "provider_readable": true,
  "reader_held": false,
  "recovery_without_user": true
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
