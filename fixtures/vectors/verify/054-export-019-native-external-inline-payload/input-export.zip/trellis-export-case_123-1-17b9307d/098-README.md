# Trellis export for case_123

- scope (manifest.scope): `case_123`
- tree_size (manifest.tree_size): `1`
- tree_head_hash (checkpoint[0].tree_head_hash): `17b9307db60bc7daed94bb6f26a4e936b1611911ce5514919f5d360f3a5dc363`
- head_checkpoint_digest: `5e565544d21887ff44edd0e15260e8f26686ca06bde6479932e6024be852790f`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "compute:native-attachment:retained-custody (readerHeld)",
  "provider_readable": false,
  "reader_held": true,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
