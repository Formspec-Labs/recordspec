# Trellis export for case_completion

- scope (manifest.scope): `case_completion`
- tree_size (manifest.tree_size): `3`
- tree_head_hash (checkpoint[2].tree_head_hash): `14df3b8205151ac9d307d585c23b2a193f9b1475431bc876e7038db8434166e5`
- head_checkpoint_digest: `d809188062e2e2bc75bc4497dfd7e9fc1c38531f629fb5657c7e00f3735517a1`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "publicMetadata",
  "provider_readable": true,
  "reader_held": false,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
