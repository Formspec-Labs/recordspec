# Trellis export for case_completion

- scope (manifest.scope): `case_completion`
- tree_size (manifest.tree_size): `3`
- tree_head_hash (checkpoint[2].tree_head_hash): `852560671c067bcaa0e437cb847ff7fa24f844364e5032ed28d024a3b071d9d2`
- head_checkpoint_digest: `99c63f114282e4fcb42089c2c11963c25aaaf1e90aaed2d2c062f3edcf289609`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "publicMetadata",
  "provider_readable": true,
  "reader_held": false,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
