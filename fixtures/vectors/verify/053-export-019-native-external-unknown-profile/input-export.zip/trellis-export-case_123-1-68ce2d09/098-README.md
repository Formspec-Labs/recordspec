# Trellis export for case_123

- scope (manifest.scope): `case_123`
- tree_size (manifest.tree_size): `1`
- tree_head_hash (checkpoint[0].tree_head_hash): `68ce2d099de67877ae18eb2ea4c9d5dde74590020157c1aa4aea2a02e16ba800`
- head_checkpoint_digest: `48727c464110890128e1acfb6fa901fc3b73132fec8b6854edc0a38ee34ded6b`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "compute:native-attachment:retained-custody (readerHeld)",
  "provider_readable": false,
  "reader_held": true,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
