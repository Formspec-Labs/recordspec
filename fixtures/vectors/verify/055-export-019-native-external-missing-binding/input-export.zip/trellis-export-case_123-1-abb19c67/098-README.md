# Trellis export for case_123

- scope (manifest.scope): `case_123`
- tree_size (manifest.tree_size): `1`
- tree_head_hash (checkpoint[0].tree_head_hash): `abb19c67a0a2dfd67eb0e353e63400bca13c9339bbeb724c5153aa0a99382b23`
- head_checkpoint_digest: `f1cc603b730e112363558cd2000b3260fa612de13335b079b802173e49e2c972`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "compute:native-attachment:retained-custody (readerHeld)",
  "provider_readable": false,
  "reader_held": true,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
