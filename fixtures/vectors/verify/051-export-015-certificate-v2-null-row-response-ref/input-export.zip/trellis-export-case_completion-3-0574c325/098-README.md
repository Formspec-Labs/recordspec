# Trellis export for case_completion

- scope (manifest.scope): `case_completion`
- tree_size (manifest.tree_size): `3`
- tree_head_hash (checkpoint[2].tree_head_hash): `0574c3259c9216fb3db0519e06d1bc5d6625c47602ec548761d5794caff09c37`
- head_checkpoint_digest: `c62416343426c5e365000eaa858f63c1d94e44e5047919f47c012a929307d634`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "publicMetadata",
  "provider_readable": true,
  "reader_held": false,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
