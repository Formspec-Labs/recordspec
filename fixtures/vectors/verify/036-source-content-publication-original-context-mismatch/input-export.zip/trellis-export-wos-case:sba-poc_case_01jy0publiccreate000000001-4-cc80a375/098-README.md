# Trellis Export (Fixture) — Source-signed task publication

Mixed-family Source-content publication fixture.
