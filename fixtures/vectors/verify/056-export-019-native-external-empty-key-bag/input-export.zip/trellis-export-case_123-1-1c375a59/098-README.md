# Trellis export for case_123

- scope (manifest.scope): `case_123`
- tree_size (manifest.tree_size): `1`
- tree_head_hash (checkpoint[0].tree_head_hash): `1c375a59b67cd4aac7bc361c09d4c1ad69c8a60eb3d9a470eeef925183320155`
- head_checkpoint_digest: `6f27f7923862be8e45d6ac0112b68d8fd3c599f43acfa859ab769c1eda571cdf`
- registry_digest: `1b2dd29c1fab2bb8b22a293638075eb955c7505844bc6ecfa1044950e24a5608`

## Posture Declaration (manifest.posture_declaration)
```json
{
  "delegated_compute": false,
  "external_anchor_name": null,
  "external_anchor_required": false,
  "metadata_leakage_summary": "compute:native-attachment:retained-custody (readerHeld)",
  "provider_readable": false,
  "reader_held": true,
  "recovery_without_user": false
}
```

## Omitted payload checks
```json
[]
```

## Verify
Run `./090-verify.sh` from this directory (or run your verifier directly).
